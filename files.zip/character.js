// Simple 3D animated character using Three.js
const canvasDiv = document.getElementById('character-canvas');
if (canvasDiv) {
  // Setup Three.js scene
  const scene = new THREE.Scene();
  const camera = new THREE.PerspectiveCamera(55, canvasDiv.clientWidth / canvasDiv.clientHeight, 0.1, 1000);
  const renderer = new THREE.WebGLRenderer({ alpha: true, antialias: true });
  renderer.setClearColor(0x000000, 0); // transparent
  renderer.setSize(canvasDiv.clientWidth, canvasDiv.clientHeight);
  canvasDiv.appendChild(renderer.domElement);

  // Lighting
  const light = new THREE.PointLight(0xffffee, 1.1, 100);
  light.position.set(10, 15, 10);
  scene.add(light);
  const ambient = new THREE.AmbientLight(0xffffff, 0.7);
  scene.add(ambient);

  // 3D Character (simple robot head with animated eyes and floating effect)
  const headGeometry = new THREE.SphereGeometry(1.0, 32, 32);
  const headMaterial = new THREE.MeshStandardMaterial({ color: 0x00cfff, metalness: 0.4, roughness: 0.4 });
  const head = new THREE.Mesh(headGeometry, headMaterial);
  head.position.y = 0.2;
  scene.add(head);

  // Eyes
  const eyeGeometry = new THREE.SphereGeometry(0.15, 16, 16);
  const eyeMaterial = new THREE.MeshStandardMaterial({ color: 0xffffff, emissive: 0x4444ff });
  const leftEye = new THREE.Mesh(eyeGeometry, eyeMaterial);
  leftEye.position.set(-0.35, 0.35, 0.89);
  const rightEye = new THREE.Mesh(eyeGeometry, eyeMaterial);
  rightEye.position.set(0.35, 0.35, 0.89);
  head.add(leftEye);
  head.add(rightEye);

  // Pupils
  const pupilGeometry = new THREE.SphereGeometry(0.06, 10, 10);
  const pupilMaterial = new THREE.MeshStandardMaterial({ color: 0x111133 });
  const leftPupil = new THREE.Mesh(pupilGeometry, pupilMaterial);
  leftPupil.position.set(0, 0, 0.16);
  leftEye.add(leftPupil);
  const rightPupil = new THREE.Mesh(pupilGeometry, pupilMaterial);
  rightPupil.position.set(0, 0, 0.16);
  rightEye.add(rightPupil);

  // Antenna
  const antennaGeometry = new THREE.CylinderGeometry(0.07, 0.07, 0.7, 16);
  const antennaMaterial = new THREE.MeshStandardMaterial({ color: 0xffeb3b, emissive: 0xfbc02d });
  const antenna = new THREE.Mesh(antennaGeometry, antennaMaterial);
  antenna.position.set(0, 1.07, 0);
  head.add(antenna);

  // Antenna tip
  const tipGeometry = new THREE.SphereGeometry(0.14, 12, 12);
  const tipMaterial = new THREE.MeshStandardMaterial({ color: 0xffd600, emissive: 0xffe082 });
  const antennaTip = new THREE.Mesh(tipGeometry, tipMaterial);
  antennaTip.position.set(0, 0.35, 0);
  antenna.add(antennaTip);

  camera.position.z = 3.5;

  // Animate
  let t = 0;
  function animate() {
    requestAnimationFrame(animate);
    t += 0.035;
    // Float up and down
    head.position.y = 0.2 + Math.sin(t) * 0.12;
    // Antenna tip glow
    antennaTip.material.emissiveIntensity = 1.3 + 0.7 * Math.abs(Math.sin(t * 2));
    // Eyes: pupils follow mouse (if on quiz page)
    if (window.latestMouse) {
      const mx = (window.latestMouse.x / window.innerWidth - 0.5) * 2;
      const my = (window.latestMouse.y / window.innerHeight - 0.5) * 2;
      leftPupil.position.x = THREE.MathUtils.clamp(mx * 0.09, -0.08, 0.08);
      leftPupil.position.y = THREE.MathUtils.clamp(my * 0.07, -0.07, 0.07);
      rightPupil.position.x = THREE.MathUtils.clamp(mx * 0.09, -0.08, 0.08);
      rightPupil.position.y = THREE.MathUtils.clamp(my * 0.07, -0.07, 0.07);
    }
    renderer.render(scene, camera);
  }
  animate();

  // Mouse tracking for eyes
  window.latestMouse = { x: window.innerWidth / 2, y: window.innerHeight / 2 };
  window.addEventListener('mousemove', e => {
    window.latestMouse.x = e.clientX;
    window.latestMouse.y = e.clientY;
  });
  window.addEventListener('touchmove', e => {
    if (e.touches && e.touches.length > 0) {
      window.latestMouse.x = e.touches[0].clientX;
      window.latestMouse.y = e.touches[0].clientY;
    }
  });
  // Responsive
  window.addEventListener('resize', () => {
    renderer.setSize(canvasDiv.clientWidth, canvasDiv.clientHeight);
    camera.aspect = canvasDiv.clientWidth / canvasDiv.clientHeight;
    camera.updateProjectionMatrix();
  });
}