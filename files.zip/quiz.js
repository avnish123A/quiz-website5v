// Simple quiz logic for quiz.html

const quizData = [
  {
    question: "What is the capital of France?",
    options: ["London", "Madrid", "Paris", "Berlin"],
    answer: 2
  },
  {
    question: "Who wrote 'To the Moon'?",
    options: ["Neil Armstrong", "Kan Gao", "Elon Musk", "Isaac Asimov"],
    answer: 1
  },
  {
    question: "What is 7 x 8?",
    options: ["54", "56", "64", "48"],
    answer: 1
  },
  {
    question: "Which planet is known as the Red Planet?",
    options: ["Venus", "Mars", "Jupiter", "Saturn"],
    answer: 1
  }
];

let current = 0;
let score = 0;
let selected = null;

const questionDiv = document.getElementById('quiz-question');
const optionsDiv = document.getElementById('quiz-options');
const nextBtn = document.getElementById('next-btn');
const resultDiv = document.getElementById('quiz-result');
const progressDiv = document.getElementById('quiz-progress');

function showQuestion(idx) {
  selected = null;
  const q = quizData[idx];
  questionDiv.textContent = q.question;
  optionsDiv.innerHTML = '';
  q.options.forEach((opt, i) => {
    const btn = document.createElement('button');
    btn.textContent = opt;
    btn.className = 'quiz-option';
    btn.onclick = () => {
      [...optionsDiv.children].forEach(b => b.classList.remove('selected'));
      btn.classList.add('selected');
      selected = i;
      nextBtn.style.display = 'inline-block';
    };
    optionsDiv.appendChild(btn);
  });
  progressDiv.textContent = `Question ${idx + 1} of ${quizData.length}`;
  nextBtn.style.display = 'none';
  resultDiv.style.display = 'none';
}

function showResult() {
  questionDiv.textContent = '';
  optionsDiv.innerHTML = '';
  progressDiv.textContent = '';
  resultDiv.style.display = '';
  resultDiv.innerHTML = `<span>Your Score: ${score} / ${quizData.length}</span><br>
    ${score === quizData.length ? "🎉 Amazing! The character is proud of you!" : "Try again for a perfect score!"}`;
  nextBtn.style.display = 'none';
}

nextBtn.onclick = () => {
  if (selected === null) return;
  if (quizData[current].answer === selected) score++;
  current++;
  if (current < quizData.length) {
    showQuestion(current);
  } else {
    showResult();
  }
};

// Start
showQuestion(current);